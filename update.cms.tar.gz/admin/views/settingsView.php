<?php

class settingsView extends View
{
    // pola formularza
    public $IdUser;
    public $IdLang;
    public $Email;
    public $FirstName;
    public $LastName;
    public $Nick;
    
    
    public function __construct()
    {
        parent::__construct();
    }

}

