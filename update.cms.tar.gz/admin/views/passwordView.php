<?php

class passwordView extends View
{
    public $Password;
    public $RepeatPassword;

    public function __construct()
    {
        parent::__construct();
    }
}
