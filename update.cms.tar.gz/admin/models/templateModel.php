<?php
/**
 * userModel
 * 
 * @category   Model
 * @package    CMS
 * @author     Rafał Żygadło <rafal@maxkod.pl>
 
 * @copyright  2016 maxkod.pl
 * @version    1.0
 */

class templateModel extends fileModel
{

    public function __construct()
    {
        parent::__construct();
    }

}
