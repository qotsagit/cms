<?php

class profileView extends View
{
    
    public function __construct()
    {
        parent::__construct();
    }

}

