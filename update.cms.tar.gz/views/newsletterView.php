<?php

class newsletterView extends View
{

    public function __construct()
    {
        parent::__construct();
    }

}

