<?php

class pricingWheelView extends View
{
    
    public function __construct()
    {
        parent::__construct();
    }

}

